- ## Daily Log
    ### Today's Quote
        - 
    ### Journaling
        - "[[Who do I want to be?]]"
            -  
            - {{[[iframe]]: https://maebert.github.io/themostdangerouswritingapp/ }}
        - ### [[Gratitude Journal]]
            -  
        - Evening Questions
            - "[[What interesting ideas did I come across?]]"
                - {{Write Son:42SmartBlock:MDWA iframe}}
- ## Agenda
    - At Mya's XMas (Invalid Date - Invalid Date)
- ## ToDo's
    - {{[[TODO]]}} Write letters
- ## Mentions:
    -   
- ## Overdue ToDo's
    - "{{[[TODO]]}} Relist the subwoofer [[September 3rd, 2020]] bump to  [[January 11th, 2021]] "
    - "{{[[TODO]]}} [[September 13th, 2020]] Transfer [[thestoicclock.com]] to cloudfare or another service on https://help.heroku.com/NH44MODG/my-root-domain-isn-t-working-what-s-wrong"
    - "{{[[TODO]]}} #na   Do all of this [[September 14th, 2020]] "
    - "{{[[TODO]]}} #na   [[September 30th, 2020]] https://www.monsterchildren.com/best-documentaries-to-watch-stoned/?utm_source=morning_brew"
    - "{{[[TODO]]}} #weekend  [[January 30th, 2021]] write [[Dad]] a thank you letter for bringing me on-board."
    - "{{[[TODO]]}} [[December 9th, 2020]] import all of the skyspark data names into a spreadsheet "
    - "{{[[TODO]]}} #weekend  [[January 30th, 2021]] write [[Dad]] a thank you letter for bringing me on-board."
    - "{{[[TODO]]}} If the intersection decision is made, I can build that model out. Check back [[January 4th, 2021]] 
This should be #Prio-1 if the decisions is made  "
    - "{{[[DONE]]}} First step is to discuss with [[Dr. Hainen]] or one of his grad students and discuss what we are seeing. 

Wait on [[Dr. Hainen]]'s reply, check back [[December 17th, 2020]] "
- Other:
    - Letter for [[Ross]]:
        - Dear Ross,
        - I wrote everyone else a letter last year - ran out of time on yours, and I have felt bad about that so I thought that I would write you one this year...
        - I wasn't a good big brother for a long time - maybe I still kinda suck tbh. I think that a lot of it had to do with the fact that you are so damn good at everything ross. At 4 years younger than me, you equaled or were poised to surpase me at most sports, video games - you name it. I struggled with that for some reason and at times definitely thought of you as my rival.
        - At the same time, I have always been incredibly proud to be your older brother. I tell people so pridefully that you are my younger brother
        - I have always wanted to be better friends with you Ross, but haven't taken any steps to make it happen. I know that growing up I was always condescending and mean. I want to be better friends. 
        - I am sorry that I got mad at you for the decision that you made to forgoe the germany trip. I obviously really wanted you to go, but in the end you made the right decision. I should have respected that. 
        - So in addition to the socks and this letter lol, I have two options for your second gift:
        - 1) I will pay for drinks all of your 21st night (provided you are in Tuscaloosa)
        - 2) I will pay for a year of Roam Research. It has changed the way I take notes/really just keep track of my life  
