- ^^((_F75LJAFq))^^
- Agenda
    - Personal Health:
        - {{[[DONE]]}} Workout or run
        - {{[[DONE]]}} Evening focus hour
        - {{[[DONE]]}} read for pleasure, watch something, go for a walk
    - Actual:
        - {{[[DONE]]}}  Helped Mat with [[[[Hanson]]/  BAS Data Export]]
            - {{[[DONE]]}} Record  1 hour + [[October 18th, 2020]]'s work (3 hours)
        - {{[[DONE]]}} Make [[10/19 -- 10/26/2020]]
- [[Did you do your best today?]]
    - I was a dumb ass and hooked up powered CAN to the passive CAN on the ECM module. See "{{[[DONE]]}} #na  Tested the CAN on the ECM"

I probably blew that CAN bus, as it is short-circuited. Hopefully, it is isolated from the other functions of the ECM. 

I need to remember that Lab stuff is not software and I have to think through things before I do them. #[[Improving Max]] 
