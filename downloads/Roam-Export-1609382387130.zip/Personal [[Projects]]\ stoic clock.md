- The clock's username is **pi**
- # [[TODO]]
    - {{[[TODO]]}} non 24 hour mode appears to not work??
        - errored out the script [[November 20th, 2020]]  
    - {{[[DONE]]}} Figure out why 6 doesn't show on nixie tube 3
    - {{[[DONE]]}} Power the Raspberry Pi via 5v pin
    - {{{[[DONE]]}}}} Check if I am still logging API errors
    - {{[[TODO]]}} Setup the raspberry pi with the bluetooth internet connect
        - IP = 10.220.189.19
    - {{{[[DONE]]}}}} Get the Website up and running!
        - Need to add my account
        - bought [[thestoicclock.com]] from [[GoDaddy]]
        - {{[[TODO]]}} [[September 13th, 2020]] Transfer [[thestoicclock.com]] to cloudfare or another service on https://help.heroku.com/NH44MODG/my-root-domain-isn-t-working-what-s-wrong
    - {{[[TODO]]}} Build a case
        - Measure and design the base 
- # Organized Steps:
    - ### Build a Case:
        - Info:
            - Plexiglass cover: https://www.shoppopdisplays.com/CS001/5-sided-clear-acrylic-box-custom-size.html?v=85&gclid=Cj0KCQjwl4v4BRDaARIsAFjATPkK7YKXnjoAxTpsJu9xSwBx7_g5NIPqQ6wowMqx8Afc64PyaDHzS0waAlutEALw_wcB
        - ^^Include a LED that lights up backlit memento mori coin^^
            - https://store.dailystoic.com/collections/memento-mori/products/memento-mori
                - might have to reach out to stoic daily to use
            - maybe print the coin on frosted glass. Light with LED
                - the LED needs to match the tubes?
        - Make the case out of cement type stuff
            - Mom says they sell hobby cement to cover wooden boxes
            - https://www.homedepot.com/p/94-lb-Portland-Cement-112494/100570364?irgwc=1&cm_mmc=afl-ir-12116-456723-&clickid=XiS2ZmWfGxyORPSwUx0Mo3YXUkiUtDRG2WzsUg0
            - or concrete counter top mix
            - ^^Acrylic Cover^^:
                - https://www.homedepot.com/p/OPTIX-24-in-x-48-in-x-093-in-Acrylic-Sheet-MC-13/202038048
            - ![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fmax-schrader%2F1acTZyIn2s.png?alt=media&token=6620a0b0-3fdc-4cb5-8d4c-7e1586e5d2bd)
    - ### Wiring
        - {{[[DONE]]}} Get bus bars (12V and Grnd)
        - {{[[DONE]]}} Get wire
        - {{[[TODO]]}} Tube on/off switch
    - ### Programming
        - Changed the clock id to three random words:
            - https://randomwordgenerator.com/noun.php
            - 3 nouns, each less than 33 letters
        - Make the id and other critical info environmental variables
        - To add clock ids:
            - `r = requests.post('http://10.0.0.79:5000/api/users/AAF', auth=('mcschrader@crimson.ua.edu', 'mouseGasKap$22'))`
        - {{[[DONE]]}} Implement the slot machine anti-cathode poisoning
        - {{[[DONE]]}} Add method for adding clocks via API
        - {{{[[DONE]]}}}} Write lil about blurb
            - {{[[DONE]]}} Implement all times new roman or something similar
            - https://fonts.google.com/specimen/EB+Garamond#license
            - Doesn't look good with the button shape. This is a future want
        - {{[[TODO]]}} Add a pause button for making decisions?
        - {{{[[DONE]]}}}} Push clock website to #Heroku
            - Adding environmental variables to #Heroku
                - https://devcenter.heroku.com/articles/config-vars
        - {{[[TODO]]}} Fix the mobile site
- # Clock V2:
    - All tubes controlled by [[raspberry pi]]
    - Use better resistors, 5v regulator and better power supply
        - https://www.tindie.com/products/tonyp7/170v-high-voltage-nixie-power-supply/
    - Nixie tubes should be removeable
    - use raspberry pi hammer header
- # Current State Dump
    - ## PCB Design:
        - https://easyeda.com/editor?authenticate=force#id=9d38f044b7f347839db8eddcd4935948
        - Once components below are selected, I can continue
        - order from https://jlcpcb.com/
        - Reference:
            - https://content.instructables.com/FL2/WNOE/K3XFLL97/FL2WNOEK3XFLL97.LARGE.jpg?auto=webp&width=1024&height=1024&fit=bounds
            - 
    - ## Components To Buy:
        - Believe that I currently have everything ordered
        - {{[[DONE]]}} Order 5v converter 
        - {{[[DONE]]}} Order Arduino vs Rasberry Pi
        - {{[[DONE]]}} Order 170 Volt converter
        - {{[[DONE]]}}  Order resistros and caps
    - ## Tools to Buy:
        - {{[[DONE]]}} Soldering Iron
        - {{[[DONE]]}} Wire Cutters
        - 
- # Random Links / Thoughts
- SSH:
    - Using ngrok
    - https://dashboard.ngrok.com/status/tunnels
- Send to Ryan Holiday for free. He might blow it up and decide to sell on his store
- Have a wake-up time setup.
    - Only display the **days left** during the wake-up hours
- see this video for reference:
    - https://www.instructables.com/id/Make-Your-Own-Retro-Nixie-Clock-With-an-RTC/
    - https://www.youtube.com/watch?v=ObgmVNV1Kfg
        - links
            - 
Parts list (incomplete, see Instructables for more, affiliate links):
Aliexpress:
4x IN-14 Nixie tube: [https://s.click.aliexpress.com/e/_dYx...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_dYxadSB&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
4x K155ID1 Nixie tube driver: [https://s.click.aliexpress.com/e/_dZ0...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_dZ02DLv&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
1x LM7805 5V regulator: [https://s.click.aliexpress.com/e/_dTT...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_dTT11Yx&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
1x Arduino Pro Mini: [https://s.click.aliexpress.com/e/_dWj...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_dWjf2yn&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
1x DS1307 RTC: [https://s.click.aliexpress.com/e/_d6i...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_d6iyPCF&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
SMD Capacitors (1206 10uF, 100nF): [https://s.click.aliexpress.com/e/_dSt...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_dSt10Z1&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
Male+Female Header: [https://s.click.aliexpress.com/e/_d8C...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_d8CsUsJ&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
4x 10kΩ Resistor: [https://s.click.aliexpress.com/e/_dVr...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_dVrRxir&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
1x 170V DC Supply: [https://s.click.aliexpress.com/e/_dTN...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_dTNNUVZ&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
1x DC Input Jack: [https://s.click.aliexpress.com/e/_Bf7...](https://www.youtube.com/redirect?v=ObgmVNV1Kfg&event=video_description&q=https%3A%2F%2Fs.click.aliexpress.com%2Fe%2F_Bf7oDayn&redir_token=u3WREO80ZDO9l0DSxHjRhNf8u3N8MTU4OTMyODE5NEAxNTg5MjQxNzk0)
    - Need driver ics. specifically 
- Use Easy EDE software to create the PCBs and electrical schematics
- The ground copper layer clearance needs to be increased to support the voltage
- Need a solder gun
- Pin 11 of an arduino mini cannot handle the voltage required to drive the IC. Hook up a pull down resistor
- ## Power Supply
    - sits on its own 
    - Bought "cheap-o" one
    - Should probably upgrade to something like:
        - https://www.tindie.com/products/tonyp7/170v-high-voltage-nixie-power-supply/
- ## Micro-controller
    - orderd rasberry pi.
    - could get from https://www.microcenter.com/product/486575/Zero_W?src=raspberrypi
- # Rasperry Pi Code/Setup
    - user: stoicclock
    - user[[Password]]: papertowelPhone
    - ### Security
        - https://www.raspberrypi.org/documentation/configuration/security.md
        - https://www.raspberrypi.org/documentation/remote-access/ssh/[[Password]]less.md#copy-your-public-key-to-your-raspberry-pi
    - ### Real Time Clock:
        - https://www.raspberrypi.org/forums/viewtopic.php?t=178763
    - ### Configuring Python 3
        - https://learn.sparkfun.com/tutorials/python-programming-tutorial-getting-started-with-the-raspberry-pi/configure-your-pi
    - ### Bluetooth/Wifi
        - https://github.com/nymea/berrylan
        - Beautiful!!!!!!!
        - Installed following the manual options and works!
        - https://www.raspberrypi.org/forums/viewtopic.php?t=164522
    - ### Working Headless:
        - https://dev.to/vorillaz/headless-raspberry-pi-zero-w-setup-3llj
    - ### Start-up Scripts with Order and Latching:
        - https://learn.sparkfun.com/tutorials/how-to-run-a-raspberry-pi-program-on-startup/all
            - Part 3
    - ### Get the current time:
        - ```import time
import os
import ntplib
client = ntplib.NTPClient()
response = client.request('pool.ntp.org')
print(time.ctime(response.tx_time))
Thu May 21 21:52:43 2020````
- # Website/Database
    - Need to create a website to interface to 
        - needs a sign-up link and account generation
        - after the account is generated, enter your date-of-birth and your expected death age.
        - The arduino will pull from this to generate the day count down  
    - https://www.simbla.com/database-createdatabase
- # Datasheets
    - K155ID1
        - https://tubehobby.com/datasheets/k155id1.pdf
- # BOM
    - ### Nixie Tubes:
        - {{[[DONE]]}} Bought
        - 6x IN-14 Nixie Tubes - $74.27
    - ### 170V DC Supply:
        - [amazon link](https://www.amazon.com/dp/B07HJX9761/ref=sspa_dk_detail_1?psc=1&pd_rd_i=B07HJX9761&pd_rd_w=gPSq0&pf_rd_p=48d372c1-f7e1-4b8b-9d02-4bd86f5158c5&pd_rd_wg=15vYt&pf_rd_r=N7691W6F811WN4VKHD31&pd_rd_r=cc113c9c-6d51-4ea6-93d7-f23f67c6774a&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUExRDJSRjNVWUpJT0xTJmVuY3J5cHRlZElkPUEwMDQyNzcwMjRYUEpQUE5HNzMxNCZlbmNyeXB0ZWRBZElkPUEwMDA1MTczMlA5RktCWFFPMlU1NiZ3aWRnZXROYW1lPXNwX2RldGFpbCZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU=)
        -  
