- ## **Background**
    - Introduce the topic, provide a brief background, and identify importance/relevance of the topic to the combustion field. Summarize
interesting, challenging, and problematic aspects of the topic. (3-5
slides)
        - [[Chemical looping combustion of solid fuels]] is a new indirect combustion process with inherent seperation of CO2. 
            - The use of solid fuels in CLC currently stands at a technical readiness level of 6.
                - When designing a CLC unit of solid fuels, the preferred configuration for the scale-up is a two [[circulating fluidized beds (CFB) system]]
            - Coal has been the most commonly used solid fuel in CLC, but biomass has recently emerged as a very promising option to achieve negative emissions using bioenergy with carbon dioxide capture and storage (#BECCS).
            - The development of Chemical Looping with Oxygen Uncoupling (#CLOU) makes a qualitative step forward in the solid fuel combustion, due to the use of materials able to release oxygen.
            - There is a chemical loop between an air reactor and a fuel reactor. Air and fuel do not physical mix or react 
                - The flue gas is a mixture of h2o and co2. The carbon dioxide can be captured by simply condensing the water vapor.
            - The technology uses metal oxide for selective oxygen transport from combustion to air.
                - The metal oxide powder combines with the oxygen in the air and transports in to the air reactor
                - Mostly low cost iron and manganese materials have been used as oxygen carriers in the so called in-situ gasification CLC (iG-CLC).
            - Consists of 2 separate reactors: air reactor and fuel reactor 
                - The sum of heat release in the two reactors is = to the heat release in traditional combustor
            - The main challenge is the requirement of excellent gas solids contact in both reactors. #fluid-dynamics in order to provide satisfactory fuel conversion
            - One of the main problems with state of the art #carbon-capture technology is the additional energy effort for separation of carbon dioxide
        - 
- ## **Scope of the Presentation**
    - Provide a brief outline of presentation, i.e., what is covered and what is not covered.  What is the focus of review in terms of technology, science (physics, chemistry, and mathematics), methodology used (experimental, computational, and analytical), topical emphasis (thermodynamics, chemical kinetics, fluid mechanics; single phase, multi-phase,
laminar or turbulent). Other aspects (social, economic, commercial, business, etc) can and should be included, but they are not be the primary focus.  Provide a summary of the presentation. (2-4 slides)
        - The presentation is focused on the current status of CLC power generation
            - technical aspects:
                - 
- ## **Purpose and Terminology**
    - **Purpose and Terminology**: Discuss
the end goal or purpose in studying the topic. 
Explain the problem with the help of diagrams and/or photographs. Identify
and define the important terms used in the field. (4-6 slides)
        - The purpose of this presentation is to gain an understanding of CLC 
            - Why is is being pursued
            - The technical challenges facing implementation
        - The technical terms needed for the review are:
            - CLC - Chemical Looping Combustion
            - solid fuel CLC - solid fuel looping combustion
            - in-situ gasification
            - fluidized bed reactors or fbr
            - moving bed 
            - Technical Readiness Level or TRL
            - CLOU
                - chemical looping with oxygen uncoupling
            - oxidizer,reoxidizer
- ## **Chronological Review (section 1, 2, …)**
    1. This is the largest portion of the report and it should be divided into
multiple sections with increasing level of complexity.  
    2. Start each section with a brief overview and end it with a brief summary.  In
each section, identify past accomplishments and the current state of
the art. 
    3. Give mathematical equations, method of analysis,
experimental procedures, and results (as appropriate) and their
interpretation to effectively communicate ideas to the viewer. 
    4. Again, start with simple material that everyone in the audience could
understand while building interest in the topic, and then increase
the complexity to present more realistic situations.  Each section
should include hardware aspects of the combustor, how fuel and air
are brought together, chemical aspects of the fuel, and discussion of
emissions produced. (20-30 slides)
    5.  __section 1__
        1. Chemical looping combustion metal oxide reactions
    6. __section 2__
- ## **Summary and Future Work**
- ## **Acknowledgements**
- ## **References**
- ## **Appendices**
- 
