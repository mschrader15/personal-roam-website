- ## Daily Log
    ### Today's Quote
        - **Epictetus**
        - Other people's views and troubles can be contagious. Don't sabotage yourself by unwittingly adopting negative, unproductive attitudes through your associations with others.
    ### Journaling
        - "[[How do I want to live?]]"
            - {{Write Son:42SmartBlock:MDWA iframe}}
        - ### [[Gratitude Journal]]
            -  I am thankful 
        - Evening Questions
            - "[[What made me sad?]]"
                - {{Write Son:42SmartBlock:MDWA iframe}}
- ## Agenda
    - Biopsy @ Main Hospital (10:30:00 AM - 11:30:00 AM)
    - Submit Hanson Hours (4:30:00 PM - 5:30:00 PM)
- ## ToDo's
    - 
- ## Mentions:
    -  
- ## Overdue ToDo's
    - "{{[[TODO]]}} Relist the subwoofer [[September 3rd, 2020]] bump to  [[January 11th, 2021]] "
    - "{{[[TODO]]}} [[September 13th, 2020]] Transfer [[thestoicclock.com]] to cloudfare or another service on https://help.heroku.com/NH44MODG/my-root-domain-isn-t-working-what-s-wrong"
    - "{{[[TODO]]}} #na   Do all of this [[September 14th, 2020]] "
    - "{{[[TODO]]}} #na   [[September 30th, 2020]] https://www.monsterchildren.com/best-documentaries-to-watch-stoned/?utm_source=morning_brew"
    - "{{[[TODO]]}} #weekend  [[January 30th, 2021]] write [[Dad]] a thank you letter for bringing me on-board."
    - "{{[[TODO]]}} [[December 9th, 2020]] import all of the skyspark data names into a spreadsheet "
    - "{{[[TODO]]}} #weekend  [[January 30th, 2021]] write [[Dad]] a thank you letter for bringing me on-board."
    - "{{[[TODO]]}} If the intersection decision is made, I can build that model out. Check back [[January 4th, 2021]] 
This should be #Prio-1 if the decisions is made  "
    - "{{[[DONE]]}} First step is to discuss with [[Dr. Hainen]] or one of his grad students and discuss what we are seeing. 

Wait on [[Dr. Hainen]]'s reply, check back [[December 17th, 2020]] "
