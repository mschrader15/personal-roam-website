- Google Calendar::mcschrader@crimson.ua.edu
- {{[[roam/js]]}}
    - ```javascript
var installScript = name => {var existing = document.getElementById(name);if (existing) {return;}var extension = document.createElement("script");extension.type = "text/javascript";extension.src = `https://roamjs.com/${name}.js`;extension.async = true;extension.id = name;document.getElementsByTagName("head")[0].appendChild(extension);};installScript("google-calendar");```
