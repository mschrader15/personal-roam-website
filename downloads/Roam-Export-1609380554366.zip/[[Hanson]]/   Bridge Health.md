- ## ToDo:
    - {{[[DONE]]}} Decide on a dashboard design by [[November 26th, 2020]] 
        - {{[[DONE]]}} 2 hours [[November 25th, 2020]]  (not submitted)
        - {{[[DONE]]}} 1 hour [[November 26th, 2020]] (not submitted)
        - {{[[DONE]]}} 1.5 hour [[December 1st, 2020]]
            - Learning [[[[Coding]]/  Next.js]]
    - ### Plotting:
        - {{[[TODO]]}} Need to decide on the library for plotting:
            - https://developers.arcgis.com/javascript/latest/sample-code/layers-kml/index.html
            - https://openlayers.org/en/latest/examples/select-features.html
            - https://github.com/sacridini/Awesome-Geospatial
    - ### Navbar:
        - https://css-tricks.com/hamburger-menu-with-a-side-of-react-hooks-and-styled-components/
- ## Meetings:
    - {{[[DONE]]}} [[October 20th, 2020]] Meeting with Tony @2:00PM
        - ToDos:
            - {{[[DONE]]}} Put together a storyboard mockup of the website [[October 27th, 2020]]
                - Have a mockup of the site with the alerts and input outputs
                    - Like an actual sketch
            - Travis Painter 
            - Riley's Colleague builds building sensors
                - Getting an NDA together
                - I will get involved in the talks of the backend data
        - FirstStreet API:
            - Tony reached out to the 
            - {{[[DONE]]}} Look into scanning the website for colors to get depth and probability [[October 24th, 2020]] 
                - We use that to get a depth and probability
                - I can extract the info from 

https://floodfactor.com/property/6319-edge-water-dr-monroe-county-illinois/173479902_fsid#flood_risk_explorer

Flood Risk Explorer Table

^^the main issue is that you can't enter coordinates^^
                - {{[[DONE]]}} Email the team about this [[October 26th, 2020]] 
        - 
- ## Design:
    - https://balsamiq.cloud/sf5pctq/p25octi/r2278
- {{{[[DONE]]}}}} [[August 23rd, 2020]] build a Dash dashboard with this info as MVP https://waterservices.usgs.gov/rest/IV-Service.html
    Delivered to [[Hanson]]: https://hanson-bridge-health.herokuapp.com/
- As of [[November 25th, 2020]], I have the go ahead to develop the application
- [[August 24th, 2020]]
    - Used contextual threading #Lessons-Learned to hopefully deal with app crashes: https://docs.sqlalchemy.org/en/13/orm/contextual.html#using-thread-local-scope-with-web-applications
    - https://docs.sqlalchemy.org/en/13/orm/session_basics.html#session-faq-whentocreate
    - Used hidden divs to store data
    - Talked to [[Dad]], going to send me a bridge that they have worked on in the past. Should have more data 
- ToDo:
    - {{[[DONE]]}} Remove API and SQL keys and make environmental variables
- Ideas:
    - {{[[DONE]]}} Bridge upload and entry from either a dash table or have an upload spreadsheet option. Display the spreadsheet with the interpreted values before committing it to the database 
- Potential APIs:
    - https://www.weather.gov/documentation/services-web-api
        - Use coords of bridge and then get the weather location.
        - Access Token:
            - https://www.ncdc.noaa.gov/cdo-web/token
            - nWRDJfRUxfuBTRtNQvzvukkFuyXGemPy 
    - site4
        - **f0ba75a422b9742251ae12ae17c0e027**
    - https://waterservices.usgs.gov/rest/IV-Service.html
    - NOAA AHPS (flood prediction)
        - https://water.weather.gov/ahps/download.php
            - https://pypi.org/project/pyshp/
            - https://stackoverflow.com/questions/33488179/how-do-i-download-pdf-file-over-https-with-python
            - ```clojure
r = requests.get('https://water.weather.gov/ahps/download.php?data=tgz_fcst_f072')
with open("data.tgz", 'wb') as f:
    f.write(r.content)

Then I will need to unzip and process the data with the pyshp```
    - Get elevation from Lat/Lon:
        - https://www.opentopodata.org/
        - or use the https://waterdata.usgs.gov/nwis/inventory/?site_no=06935550&agency_cd=USGS
            - and beautiful soup to scrape the gage datum from here
- Railway Bridges:
    - http://www.nscorp.com/content/nscorp/en/system-overview.html
- Will need a database. Bridge is the main table
    - Bridge includes bridge specifics. Tie to volume sensor and/or
- Dash Example:
    - https://github.com/plotly/dash-sample-apps/tree/master/apps/dash-oil-and-gas
    - https://towardsdatascience.com/how-to-build-a-complex-reporting-dashboard-using-dash-and-plotl-4f4257c18a7f
- Database:
    - https://aws.amazon.com/getting-started/tutorials/create-connect-postgresql-db/
    - On Azure
        - [[Password]]: br1dge-health
- #[[Dash]] example: https://towardsdatascience.com/how-to-embed-bootstrap-css-js-in-your-python-dash-app-8d95fc9e599e?source=email-f1994bb05da2-1597822861557-digest.reader------0-59------------------c43046d6_48b8_45b0_8657_9f2729943983-16-----&gi=c0ffd6b667e0 
