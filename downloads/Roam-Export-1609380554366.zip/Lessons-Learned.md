- {{[[query]]: {or: [[Lessons-Learned]] [[Lessons-Learned]]}}}
- if there is a alias issue with a GraphQL query, you can add alias like:
```clojure
query ($e: String!, $p: String!, $loc1: ID!, $loc2: ID!) {
  getSecurityToken(email: $e, [[Password]]: $p)
$$$THIS IS THE ALIAS$$$  node1: node(id: $loc1) {
    ... on Location {
      name
      id
      lastSampleForAllSensorTypes {
        edges {
          node {
            id
            finalValue
            timeUTC
            sensorModel {
              type {
                name
                units
              }
            }
          }
        }
      }
    }
  }```
- [[python]]
    - Error Logging:
        - https://stackoverflow.com/questions/30770981/logging-handlers-smtphandler-raises-smtplib-smtpauthenticationerror
- #python #database #mssql
    - https://github.com/catherinedevlin/ipython-sql/issues/54
    - https://github.com/matt-bertoncello/python-pyodbc-buildpack #Heroku
        - necessary to use Microsft database driver on #Heroku
- #python #jupyter
    - To export to PDF with plotly figure:
        - ```python
from IPython.display import Image

image_bytes = fig.to_image(format='png', width=1200, height=700, scale=1)
Image(image_bytes)```
- #bash #linux
    - to run a cron task at login see: https://www.endpoint.com/blog/2013/05/28/login-shells-in-scripts-called-from-cron

using the correct header fixed my script
- #linux #video
    - Convert a .MOV to .MP4
    - ```javascript
ffmpeg -i 'Disco Trees 1.mov' -c:v libx264 -c:a aac -strict experimental C0005_H264.mp4```
