- Status:: #digested on [[November 15th, 2020]]
- Link:: https://marginalrevolution.com/marginalrevolution/2018/10/high-return-activity-raising-others-aspirations.html
- Author:: [[Tyler Cowen]]
- Tags:: #Career #Inspiration  #Mentorship  #Leadership
- Quotes::
    - __At critical moments in time, you can raise the aspirations of other people significantly, especially when they are relatively young, simply by suggesting they do something better or more ambitious than what they might have in mind.  It costs you relatively little to do this, but the benefit to them, and to the broader world, may be enormous.

This is in fact one of the most valuable things you can do with your time and with your life.__
- Notes:: 
    - Tyler Cowen tries to raise strong Master's Candidates applications and get them to apply for the PhD program. He has gotten two of his best students in this way.   
