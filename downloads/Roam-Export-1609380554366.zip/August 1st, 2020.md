- {{{[[DONE]]}}}} Go to the Farmers Market
    - No sweet potatoes
    - {{{[[DONE]]}}}} Bread
- {{{[[DONE]]}}}} Take Recycling
- [[Energy Analysis - Transportation Research - Part C]]
    - {{{[[DONE]]}}}} Write 1000 Words
        - 2512 Words @ 12:00
        - 3011 @ 18:42
        - 
    - 7/31/2020 - 2/13/2020 worked well. Real well
        - When caculating the GEH for 63069008, I need to apply the offset for the  
- [[[[Research]] [[Future Work]]]]
    - Optimize light control to minimize kinetic energy loss
- {{{[[DONE]]}}}} Run 6+ miles
- [[August 5th, 2020]]
- [[Speaker]]
    - A speaker needs to feel like it has gravity because it is pushing sound out
- [[SUMO]] [[[[Traffic]] Simulation]]
    - [[Pattern Language]] for starting a new network simulation
        - Start with the sensor data. Try to create a picture of the network from the sensors themselves
        - Hunt for irregularites
- [[[[Quotes]] to live by]]
    - "Ideas that excite you are the best alarm clocks"
    - The home run theory of careers:

What matters is eventually hitting a home run, and the way to do that is training hard and a lot of at-bats. You only have to be right once, and it's ok to be wrong a lot of times.

Be bold. Move fast. Work hard. Ignore haters. Keep swinging.
        - - Sam Altman
