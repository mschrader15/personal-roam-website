- ^^((_F75LJAFq))^^
- [[Morning Questions]]
- Agenda
    - Personal Health:
        - {{[[DONE]]}} "Five Daily Reflections"
        - {{[[DONE]]}} Check calendar for scheduled events
        - {{[[DONE]]}} Workout or run
        - {{[[DONE]]}} Gratitude Journal
        - {{[[DONE]]}} Evening focus hour
        - {{[[DONE]]}} read for pleasure, watch something, go for a walk
    - Actual:
        - {{[[DONE]]}}  Emailed Paula about the [[GLE Project]] dSPACE questison
        - {{[[DONE]]}} Got the motor on the cummins to spin #[[[[IC Engines ME 591-005]]/ Project]]
        - {{[[DONE]]}} Picked up [[Mya]] at the airport
        - Read [[[[Article]]/ How Apple Is Organized for Innovation]]
        - Plan [[October 27th, 2020]]
- [[What's the one thing I need to get done today to make progress?]]:
    -  
- [[Brain Dump]]
    -  
- [[What interesting ideas did I come across?]]
    - A HUD for delivery trucks/vehicles #[[Business Ideas]]
    - #[[Business Ideas]] A club that does month long competitions as well as weekly meetings for  
- [[[[Ideas]]/  10 a day]]
    -  
- [[Evening Questions]]
    - Gratitude Journal::
        - I am thankful for the birds that were chirping when I woke up. It was an energetic song for the morning #Nature
    - Did you do your best today?::
    - What made me happy today?::
    - What made me sad?::
        - [[Mya]] and I got into a little spat. While we were at [[Aldi]], she got overwhelmed when her card didn't work - and then got overwhelemed again when the cart wouldn't give her money back.

She did the thing when she gets really quite. I need to understand that when that happens, she is upset with herself. 

She later told me that it was because she felt like she was acting like a ditz in front of me, and that she is afraid that I just think of her as a ditz.  

I need remind her of how intelligent I think that she is #[[Improving Max]]  
    - What Happened Today::
        - 
-  
