- Status:: #digested
- Link:: https://hbr.org/2020/11/how-apple-is-organized-for-innovation
- Author:: Morten T. Hansen, Joel M. Podolny
- Tags:: #Leadership  #Organization #[[Organizational Structure]] #[[Functional Organization]]
- Quotes::
    - "To create such innovations, Apple relies on a structure that centers on functional expertise. Its fundamental belief is that those with the most expertise and experience in a domain should have decision rights for that domain. This is based on two views: First, Apple competes in markets where the rates of technological change and disruption are high, so it must rely on the judgment and intuition of people with deep knowledge of the technologies responsible for disruption. ^^Long before it can get market feedback and solid market forecasts, the company must make bets about which technologies and designs are likely to succeed in smartphones, computers, and so on. Relying on technical experts rather than general managers increases the odds that those bets will pay off^^
    - In a functional organization, individual and team reputations act as a control mechanism in placing bets. A case in point is the decision to introduce the dual-lens camera with portrait mode in the iPhone 7 Plus in 2016. It was a big wager that the camera’s impact on users would be sufficiently great to justify its significant cost.

One executive told us that Paul Hubel, a senior leader who played a central role in the portrait mode effort, was “out over his skis,” meaning that he and his team were taking a big risk: If users were unwilling to pay a premium for a phone with a more costly and better camera, the team would most likely have less credibility the next time it proposed an expensive upgrade or feature. The camera turned out to be a defining feature for the iPhone 7 Plus, and its success further enhanced the reputations of Hubel and his team.[*](In a functional organization, individual and team reputations act as a control mechanism in placing bets. A case in point is the decision to introduce the dual-lens camera with portrait mode in the iPhone 7 Plus in 2016. It was a big wager that the camera’s impact on users would be sufficiently great to justify its significant cost.

One executive told us that Paul Hubel, a senior leader who played a central role in the portrait mode effort, was “out over his skis,” meaning that he and his team were taking a big risk: If users were unwilling to pay a premium for a phone with a more costly and better camera, the team would most likely have less credibility the next time it proposed an expensive upgrade or feature. The camera turned out to be a defining feature for the iPhone 7 Plus, and its success further enhanced the reputations of Hubel and his team. {{[[∆]]:5+2}}) {{[[r/moved]]}}
    - ^^Whereas the fundamental principle of a conventional business unit structure is to align accountability and control, the fundamental principle of a functional organization is to align expertise and decision rights.^^
    - ""Apple’s leaders believe that world-class talent wants to work for and with other world-class talent in a specialty. It’s like joining a sports team where you get to learn from and play with the best.""
    - "If you’re a great person, why do you want to work for somebody you can’t learn anything from? And you know what’s interesting? You know who the best managers are? They are the great individual contributors who never, ever want to be a manager but decide they have to be…because no one else is going to…do as good a job.”  -- [[Steve Jobs]]  [*](((SeamdWV6h))) {{[[r/moved]]}}
    - One principle of Apple's: “Leaders should know the details of their organization three levels down,”
    - "Leaders are expected to hold strong, well-grounded views and advocate forcefully for them, yet also be willing to change their minds when presented with evidence that others’ views are better." [*](((MsCB-dxcJ))  {{[[∆]]:5+2}}) {{[[r/moved]]}}
- Notes:: 
    - Apple's commitment to the best possible products would be undercut if the short-term profit and cost targets overrode the long-term company goals.#longtermism
    - The finance team is not involved in the product road map meetings of engineering teams, and engineering teams are not involved in pricing decisions.
        - Senior Executive Bonuses are based on company-wide performance, not the performance of their specific line
    - Team leader reputation is on the line with every product decision that the team makes, see:
        - "In a functional organization, individual and team reputations act as a control mechanism in placing bets. A case in point is the decision to introduce the dual-lens camera with portrait mode in the iPhone 7 Plus in 2016. It was a big wager that the camera’s impact on users would be sufficiently great to justify its significant cost.

One executive told us that Paul Hubel, a senior leader who played a central role in the portrait mode effort, was “out over his skis,” meaning that he and his team were taking a big risk: If users were unwilling to pay a premium for a phone with a more costly and better camera, the team would most likely have less credibility the next time it proposed an expensive upgrade or feature. The camera turned out to be a defining feature for the iPhone 7 Plus, and its success further enhanced the reputations of Hubel and his team.[*](In a functional organization, individual and team reputations act as a control mechanism in placing bets. A case in point is the decision to introduce the dual-lens camera with portrait mode in the iPhone 7 Plus in 2016. It was a big wager that the camera’s impact on users would be sufficiently great to justify its significant cost.

One executive told us that Paul Hubel, a senior leader who played a central role in the portrait mode effort, was “out over his skis,” meaning that he and his team were taking a big risk: If users were unwilling to pay a premium for a phone with a more costly and better camera, the team would most likely have less credibility the next time it proposed an expensive upgrade or feature. The camera turned out to be a defining feature for the iPhone 7 Plus, and its success further enhanced the reputations of Hubel and his team. {{[[∆]]:5+2}}) {{[[r/moved]]}}"
    - ### Each Leader at Apple is expected to have 3 Leadership Characteristics:
        - **Deep Expertise**
            - Stick in your lane, experts manage experts
            - "Apple’s leaders believe that world-class talent wants to work for and with other world-class talent in a specialty. It’s like joining a sports team where you get to learn from and play with the best."
        - **Willingness to collaboratively debate.**
            - To ship a product in a #[[Functional Organization]] (Apple has 100s of specialist teams!), many teams have to work together.
                - ^^The only that this works is through debate^^
            - Managers are expected to weigh-in as tie breakers. Thus,
                - Leaders are expected to hold strong, well-grounded views and advocate forcefully for them, yet also be willing to change their minds when presented with evidence that others’ views are better.
            - An example of  iPhone Potrait Mode Release is given: #[[Problem Solving]] #[[Reframing the Problem]]
                - Failure cases were frequent when attempting to bluring the background
                - sidestepping rare or extreme situations—what engineers call __corner cases__—would violate Apple’s strict engineering standard of zero “artifacts,” meaning “any undesired or unintended alteration in data introduced in a digital process by an involved technique and/or technology.”
                - Managment decidded to delay the release, then brought in a design team from a different project and they asked "What makes a protrait beautiful" 
                    - ^^It was the clear eyes! ^^, not the clear face
                    - Algorithm was changed to focus on the eyes and the edge cases decreased to the point of release worthy code
            - At Apple, managers have __accountability without control:__
                - You’re accountable for making the project succeed even though you don’t control all the other teams. This process can be messy yet produce great results. “Good mess” happens when various teams work with a shared purpose, as in the case of the portrait mode project.
        - **Leadership at Scale**
            - How to draw up the functional teams??
                - 
-  
