- Status:: #digested
- Link:: https://www.collaborativefund.com/blog/the-big-lessons-from-history/
- Author:: [[Morgan Housel]]
- Tags:: #History  #Lessons-Learned
- Quotes::
    - History is full of specific lessons that aren’t relevant to most people, and not fully applicable to future events because things rarely repeat exactly as they did in the past. ^^An imperfect rule of thumb is that the more granular the lesson, the less useful it is to the future.^^
    - The second kind of history to learn from are the broad behaviors that show up again and again, in multiple fields and different eras. They are the 30,000-foot takeaways from events that hide layers below the main story, often going ignored.
        - ^^ Pay attention to these!^^
    - __Then we got healthier and more naive. “As public health did its job, it became a target” of budget cuts, Lori Freeman, CEO of the National Association of Health Officials said this summer. Local health departments have lost a quarter of their workforce in the last decade.__
    - Historian Dan Carlin writes in his book __The End is Always Near__:
        - __Nothing separates us from human beings in earlier eras than how much less disease affects us. If we moderns lived for one year with the sort of death rates our pre–industrial age ancestors perpetually lived with, we’d be in societal shock.__
    - Carl Jung had a theory called enantiodromia. It’s the idea that an excess of something gives rise to its opposite: #cyclic  
        - When there are no recessions, people get confident. When they get confident they take risks. When they take risks, you get recessions.
        - When markets never crash, valuations go up. When valuations go up, markets are prone to crash.
        - Banning small forest fires [leads to](https://www.vox.com/2015/9/17/9347361/wildfire-management-prescribed-burn) big forest fires.
    - Embrace that the short run is a continuous chain of setbacks and disappointments, problems and embarrassments, breakages, recessions, depressions, bear markets, pandemics, and errors.

^^But none of those prevent the long run from being able to compound into something glorious.^^
    - In 1923, Henry Luce wanted to create a magazine called __FACTS__. It was only going to report on things that were objectively true. But Luce soon realized that was harder than you’d think. Instead he called it __TIME__, with the idea that saving readers time with succinct stories was the most value a publisher could add. “Show me a man who thinks he’s objective and I’ll show you a man who’s deceiving himself,” Luce said.
    - __No one wants to wake up every morning and say, “I don’t know 99.9% of what’s happening in the world, or what 99.9% of other people are thinking,” – it’s too hard to accept because it makes you feel like you’re not in control.__
    - __An important lesson from history is that everyone sees the world through a different lens, and incentives can cause smart people to embrace and defend ideas that range from goofy to disastrous. It shows up all over the place. The same story, again and again.__
    - __Viewing events in isolation makes it easier to place blame or admiration on a single person. It’s not until you study an event’s long roots that you recognize the chain of events that leads to something meaningful happening. And long chains of events are not the kind of thing that happens because of one person. They’re more wild and unpredictable, since each link in the chain could have gone multiple ways.

An important lesson from history is that big events are more complicated than we make them out to be – and the bigger the event, the more complexity. It makes forecasting hard, politics nasty, and learning specific lessons from big events harder than we’d like to think. The same story, again and again.__
- Notes:: 
    -  **Lesson # 1: Calm plants the seeds of crazy.**
        - Per-capita death from infectious disease in the United States declined 94% from 1900 to 2010.
        - Americans have become unfamiliar with infectious diseases as heir frequency and impact on our lives has decreased. 
        - Epidemiologists have warned that something like this could happen for years.  
        - "__Then we got healthier and more naive. “As public health did its job, it became a target” of budget cuts, Lori Freeman, CEO of the National Association of Health Officials said this summer. Local health departments have lost a quarter of their workforce in the last decade.__"
        - 
    - **Lesson # 2: Progress requires optimism and pessimism to coexist.**
        - Jim Stockdale, a famous POW from Vietnam:
            - __Oh, it’s easy. I can tell you who didn’t make it out. It was the optimists. The optimists. Yes. They were the ones who always said, ‘We’re going to be out by Christmas.’ Christmas would come and it would go. And there would be another Christmas. And they died of a broken heart.

This is what I learned from those years in the prison camp, where all those constraints just were oppressive. You must never ever confuse, on the one hand, the need for absolute, unwavering faith that you can prevail despite those constraints with, on the other hand, the need for the discipline to begin by confronting the brutal facts, whatever they are. We’re not getting out of here by Christmas.__
        - "Embrace that the short run is a continuous chain of setbacks and disappointments, problems and embarrassments, breakages, recessions, depressions, bear markets, pandemics, and errors.

^^But none of those prevent the long run from being able to compound into something glorious.^^"
        - It’s hard to realize there’s a time and a place for both (pessimism and optimism), and that the two can – and should – coexist. But it’s what you see in almost every successful long-term endeavor.
    - **Lesson # 3: People believe what they want to believe, see what they want to see, and hear what they want to hear.**
        - "In 1923, Henry Luce wanted to create a magazine called __FACTS__. It was only going to report on things that were objectively true. But Luce soon realized that was harder than you’d think. Instead he called it __TIME__, with the idea that saving readers time with succinct stories was the most value a publisher could add. “Show me a man who thinks he’s objective and I’ll show you a man who’s deceiving himself,” Luce said."
        - "__No one wants to wake up every morning and say, “I don’t know 99.9% of what’s happening in the world, or what 99.9% of other people are thinking,” – it’s too hard to accept because it makes you feel like you’re not in control.__" #[[Improving Max]]
        - "__An important lesson from history is that everyone sees the world through a different lens, and incentives can cause smart people to embrace and defend ideas that range from goofy to disastrous. It shows up all over the place. The same story, again and again.__"
    - **Lesson # 4: Important things rarely have one cause.**
        - Reality has a surprising amount of detail
    - **Lesson # 5: Risk is what you don’t see.**
        - Obvi. If you can plan and see it, it isn't that risky
-  
