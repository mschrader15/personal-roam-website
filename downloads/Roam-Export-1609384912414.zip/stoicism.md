- #42SmartBlock stoicAsync
    - <%JAVASCRIPTASYNC:```javascript
var url = 'https://cors-anywhere.herokuapp.com/' +  'https://stoic-quotes.com/api/quote';
var response = $.ajax({
  url:url,
  type:"GET", 
  dataType: 'json', 
  async:false }).responseText; 

response = JSON.parse(response);
roam42.smartBlocks.activeWorkflow.vars['stoic-author'] = response.author;
roam42.smartBlocks.activeWorkflow.vars['stoic-quote']   = response.text;
return '';```%><%NOBLOCKOUTPUT%>
    - **<%GET:stoic-author%>**
    - <%GET:stoic-quote%>
