- ## Daily Log
    - ### Today's Quote
        - **Marcus Aurelius**
        - Finally, therefore, remember your retreat into this little domain which is yourself, and above all be not disturbed nor on the rack, but be free and look at things as a man, a human being, a citizen, a creature that must die.
    - ### Journaling
        - From [[Simon Sarris]]:
            - > Remember: History happens only once. There is no reason things must remain or return to any particular state. We are always free to find our own values. But what will it take to value the ecology that fosters the unique, the creations that made some places and things so special that we call them works of art, or travel across the world just to see them?

There is a tale: Two oak trees sit at the edge of the forest. One is sound and hale, taller than all others, with prosperous limbs, the forest’s pride. The other is old and harboring sickness, rotting away inside. When the storm comes, the sickly oak will outlast the whirlwinds, but the sound oak will be destroyed, uprooted by the blast. And why? Because the branches catch the wind.
        - "[[How do I want to feel?]]"
            - {{Write Son:42SmartBlock:MDWA iframe}}
        - ### [[Gratitude Journal]]
            -  
        - Evening Questions
            - "[[What made me sad?]]"
                - {{Write Son:42SmartBlock:MDWA iframe}}
- ## Agenda
    - ~~Credit Card Auto Payment (Next Day) (8:00:00 AM - 9:00:00 AM)~~
    - No Summary (12:30:00 PM - 1:30:00 PM)
    - SUMO Virtual Review (4:00:00 PM - 5:00:00 PM) - [Zoom](https://uasystem.zoom.us/j/92996847625?from=addon)
        - ""{{[[TODO]]}} If the intersection decision is made, I can build that model out. Check back [[January 4th, 2021]] 
This should be #Prio-1 if the decisions is made  ""
        - The 120 seconds is a strict plan
            - The splits are 
        - The controller has a permissable window
            - The controller won't look
- ## ToDo's
    - "{{[[DONE]]}} First step is to discuss with [[Dr. Hainen]] or one of his grad students and discuss what we are seeing. 

Wait on [[Dr. Hainen]]'s reply, check back [[December 17th, 2020]] "
    - ""{{[[DONE]]}} Test out frequency of detector hits and the recorded hits by [[December 16th, 2020]] ""
    - "{{embed: ((coZQonJaC))}}"
    - [[[[Hanson]]/   Bridge Health]]
        - {{[[TODO]]}} Clicking on the color of warning shows the bridges with that level of warning.
        - {{[[TODO]]}} Incorporate the usgs water data. use json to save the settings
- ## Mentions:
    -  
- ## Overdue ToDo's
    - "{{[[TODO]]}} Relist the subwoofer [[September 3rd, 2020]] bump to  [[January 11th, 2021]] "
    - "{{[[TODO]]}} [[September 13th, 2020]] Transfer [[thestoicclock.com]] to cloudfare or another service on https://help.heroku.com/NH44MODG/my-root-domain-isn-t-working-what-s-wrong"
    - "{{[[TODO]]}} #na   Do all of this [[September 14th, 2020]] "
    - "{{[[TODO]]}} #na   [[September 30th, 2020]] https://www.monsterchildren.com/best-documentaries-to-watch-stoned/?utm_source=morning_brew"
    - "{{[[TODO]]}} #weekend  [[January 30th, 2021]] write [[Dad]] a thank you letter for bringing me on-board."
    - "{{[[TODO]]}} [[December 9th, 2020]] import all of the skyspark data names into a spreadsheet "
    - "{{[[TODO]]}} #weekend  [[January 30th, 2021]] write [[Dad]] a thank you letter for bringing me on-board."
    - "{{[[DONE]]}} Test out frequency of detector hits and the recorded hits by [[December 16th, 2020]] "
    - "{{[[TODO]]}} If the intersection decision is made, I can build that model out. Check back [[January 4th, 2021]] 
This should be #Prio-1 if the decisions is made  "
    - {{embed: ((coZQonJaC))}}
