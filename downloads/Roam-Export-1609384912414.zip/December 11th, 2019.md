- [[Weekly Meeting with [[Dr. Bittle]]]]
    - {{ToDo}}
        - Check next week for the 
        - Check how much the fees cost from Spence
        - 

    - Reminded Dr. Bittle about ME 594
