- [[Dr. Bittle]] [[Research]]
    - 64 core SSH
        - To port forwards jupyter:
            - ```clojure
ssh max@10.115.101.194
cd Documents/github-repos/US69
source venv/bin/activate
jupyter lab --no-browser --port=8888

ssh -N -f -L localhost:8888:localhost:8888 max@10.115.101.194```
- {{[[TODO]]}} [[August 15h, 2020]] Call Grandma
