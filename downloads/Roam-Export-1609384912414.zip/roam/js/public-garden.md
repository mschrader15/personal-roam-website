- Index
    - Website Homepage
- Filter
    - Tagged With
        - Blog Post
- Template
    - ```html
<!doctype html>
<html>
  <head>
    <meta charset="utf-8"/>
    <link href="https://fonts.googleapis.com/css?family=Alegreya+Sans:400,400i,700|Neuton:400,700" rel="stylesheet">
	<link rel="stylesheet" href="/assets/styles.css">
    <title>${PAGE_NAME}</title>
  </head>
  <body>
    <header>
      <div class="container">
          <a class="logo" href="/">
              <img src="/assets/logo.svg" alt="Max Schrader logo"/>
          </a>
          <nav class="nav">
            	<ul class="list list--nav">
              		<li class="item  item--nav">          
                  		<a href="/about/">About</a>
              		</li>
              		<li class="item  item--nav  item--current">
                		<a href="/">Writings</a>          
              		</li>
            	</ul>
			</nav>
    	</div>
	</header>
    <div id="content">
		${PAGE_CONTENT}
	</div>
  </body>
</html>```
    - 
