- [[Nassim Taleb]] on wealth:
    - https://www.safalniveshak.com/nassim-taleb-on-true-wealth/
    - #[[[[Future]] [[Goals]]]]:
 ![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2Fmax-schrader%2FxTeiD0qIHe.jpg?alt=media&token=31932b33-207a-4d01-bb80-144446d8d270)
    - 
